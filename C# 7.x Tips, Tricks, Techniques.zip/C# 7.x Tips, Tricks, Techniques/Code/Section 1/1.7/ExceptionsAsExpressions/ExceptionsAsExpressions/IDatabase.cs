﻿namespace ExceptionsAsExpressions
{
    public interface IDatabase
    {
    }
}