﻿namespace ExceptionsAsExpressions
{
    internal class Configuration
    {
        public string MinLoggingLevel { get; set; }
    }
}