﻿namespace ExpressionBodiedSyntax
{
    static class Program
    {
        static void Main()
        {
        }
    }
}
