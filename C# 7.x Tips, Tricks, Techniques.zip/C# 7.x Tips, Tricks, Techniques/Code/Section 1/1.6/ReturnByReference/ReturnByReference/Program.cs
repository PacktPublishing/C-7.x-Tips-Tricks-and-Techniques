﻿namespace ReturnByReference
{
    static class Program
    {
        static void Main()
        {
            PassValueTypesByReference.Run();
            //PassReferenceTypesByReference.Run();
            //ReferenceReturnValues.Run();
        }
    }
}
